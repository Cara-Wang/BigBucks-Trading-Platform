# Instructions:

1)Please create a config.py file under "Fintech512 Bigbucks" folder with your api_key inside before starting to use. 

*config.py example: api_key = '[your api_key]'

2)When trying to use, first run "flask --app BigBucks init-db" when you're in "Fintech512 Bigbucks" folder, then run "flask --app BigBucks --debug run"